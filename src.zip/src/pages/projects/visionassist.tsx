import { useState, useEffect } from 'react';
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { FiGithub, FiChevronLeft, FiMoon, FiSun, FiEye, FiMic, FiNavigation, FiShield, FiCpu, FiActivity } from "react-icons/fi";

const features = [
  {
    title: "Real-Time Object Detection",
    description: "YOLOv8-powered detection with 600+ object classes, smart label normalization, and directional audio feedback ('on your left', 'in front of you').",
    icon: <FiEye className="w-6 h-6" />
  },
  {
    title: "Human Analyzer",
    description: "MediaPipe-based pose, face, and hand tracking with 20+ activity classifications, emotion detection, gesture recognition, and multi-person tracking.",
    icon: <FiActivity className="w-6 h-6" />
  },
  {
    title: "Sign Language Interpreter",
    description: "ASL alphabet (A-Z), numbers (0-9), and 50+ common signs with real-time hand landmark tracking and speech output for sign-to-voice communication.",
    icon: "🤟"
  },
  {
    title: "Advanced OCR System",
    description: "Hybrid OCR with EasyOCR, Tesseract, and GPT-4o fallback. Three modes: offline, hybrid, and AI-only with smart text region detection.",
    icon: "📖"
  },
  {
    title: "Voice Assistant",
    description: "Whisper-powered voice recognition with GPT cleaning, intent detection, and natural language understanding for hands-free operation.",
    icon: <FiMic className="w-6 h-6" />
  },
  {
    title: "Scene Memory",
    description: "OpenAI embeddings for semantic memory - remembers scenes, objects, and contexts. Ask 'Have I seen this before?' or 'What was in this room?'",
    icon: "🧠"
  },
  {
    title: "Navigation System",
    description: "OpenRouteService integration with walking, wheelchair, transit, and rideshare modes. Accessibility-focused directions with landmarks.",
    icon: <FiNavigation className="w-6 h-6" />
  },
  {
    title: "Safety & Guidance",
    description: "Obstacle detection with depth estimation (MiDaS), proactive warnings for stairs, vehicles, and hazards with smart cooldowns to prevent spam.",
    icon: <FiShield className="w-6 h-6" />
  },
  {
    title: "Proactive AI Assistant",
    description: "Contextually aware helper that monitors scenes and proactively provides safety alerts, navigation cues, and helpful information.",
    icon: <FiCpu className="w-6 h-6" />
  }
];

const techStack = [
  { name: "Python", bg: "bg-blue-500" },
  { name: "OpenCV", bg: "bg-green-600" },
  { name: "YOLOv8", bg: "bg-purple-600" },
  { name: "MediaPipe", bg: "bg-red-500" },
  { name: "OpenAI GPT-4o", bg: "bg-emerald-600" },
  { name: "Whisper", bg: "bg-gray-700" },
  { name: "MiDaS", bg: "bg-indigo-500" },
  { name: "EasyOCR", bg: "bg-yellow-600" },
  { name: "Tesseract", bg: "bg-orange-500" },
  { name: "OpenRouteService", bg: "bg-cyan-600" },
  { name: "NumPy", bg: "bg-blue-700" },
  { name: "Firebase", bg: "bg-amber-500" },
];

const architectureModules = [
  { name: "controller.py", desc: "Main orchestrator (~1800 lines) - frame processing, threading, keyboard shortcuts", lines: "1800" },
  { name: "human_analyzer.py", desc: "Pose, face, hand tracking with Kalman filtering and multi-person support", lines: "1646" },
  { name: "sign_language_interpreter.py", desc: "ASL recognition with temporal pattern analysis and gesture sequences", lines: "1796" },
  { name: "navigation_client.py", desc: "Multi-modal navigation with accessibility-focused directions", lines: "970" },
  { name: "ocr_engine.py", desc: "Hybrid OCR system with region detection and reading order", lines: "632" },
  { name: "scene_memory.py", desc: "Semantic memory with OpenAI embeddings for scene recall", lines: "265" },
  { name: "guidance_engine.py", desc: "Safety guidance with depth-aware escalation and deduplication", lines: "315" },
  { name: "proactive_assistant.py", desc: "Context-aware alerts and suggestions system", lines: "327" },
];

const stats = [
  { label: "Lines of Code", value: "10,000+" },
  { label: "AI Models Integrated", value: "6" },
  { label: "Object Classes", value: "600+" },
  { label: "Gesture Recognition", value: "20+" },
  { label: "Target FPS", value: "25+" },
  { label: "ASL Signs", value: "86" },
];

export default function VisionAssistProject() {
  const [darkMode, setDarkMode] = useState(false);
  
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className={`min-h-screen transition-colors duration-500 ${darkMode ? 'bg-gradient-to-br from-gray-900 to-gray-800' : 'bg-gradient-to-br from-blue-50 to-indigo-50'}`}>
      {/* Background grid */}
      <div className={`absolute inset-0 z-0 ${darkMode ? 'bg-grid-gray-700/20' : 'bg-grid-gray-400/20'} bg-[length:80px_80px]`}></div>
      
      <div className="max-w-6xl mx-auto px-6 py-12 relative z-10">
        {/* Header */}
        <header className="flex justify-between items-center mb-16">
          <Link
            to="/#projects"
            className="group inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm shadow-sm hover:shadow-md transition-all"
          >
            <FiChevronLeft className="transition-transform group-hover:-translate-x-1" />
            <span className="font-medium text-gray-800 dark:text-gray-200">Back to Projects</span>
          </Link>
          
          <button 
            onClick={() => setDarkMode(!darkMode)}
            className="p-3 rounded-full bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm shadow-sm hover:shadow-md transition-all"
          >
            {darkMode ? <FiSun className="text-yellow-400" /> : <FiMoon className="text-indigo-700" />}
          </button>
        </header>

        {/* Hero Section */}
        <motion.div 
          className="mb-24"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex flex-col md:flex-row gap-12 items-center">
            <div className="md:w-1/2">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <div className="inline-block px-4 py-1 rounded-full bg-brand/10 dark:bg-brand/20 border border-brand/20 text-brand dark:text-brand/80 text-sm mb-4">
                  Capstone Project • AI + Computer Vision
                </div>
              </motion.div>
              
              <motion.h1 
                className="text-4xl md:text-5xl font-bold mb-6 text-gray-800 dark:text-white"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.6 }}
              >
                VisionAssist AI
                <span className="block text-2xl md:text-3xl font-normal text-gray-600 dark:text-gray-400 mt-2">
                  Smart Glasses for the Visually Impaired
                </span>
              </motion.h1>
              
              <motion.p 
                className="text-lg text-gray-600 dark:text-gray-300 mb-8"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                A comprehensive AI-powered assistive technology system integrating computer vision, 
                natural language processing, and real-time scene analysis to provide accessible 
                navigation, object detection, OCR, sign language interpretation, and intelligent 
                voice interaction for visually impaired users.
              </motion.p>

              <motion.div 
                className="flex flex-wrap gap-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
              >
                <a
                  href="https://github.com/mohalsheikh/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gray-800 dark:bg-gray-700 text-white hover:bg-gray-700 dark:hover:bg-gray-600 transition-colors"
                >
                  <FiGithub />
                  View Source Code
                </a>
              </motion.div>
            </div>

            <motion.div 
              className="md:w-1/2"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
            >
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-brand/30 to-accent/30 rounded-3xl blur-2xl opacity-50"></div>
                <div className="relative bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-8 border border-gray-700 shadow-2xl">
                  {/* Animated visualization */}
                  <div className="aspect-video bg-gray-800 rounded-lg overflow-hidden relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-6xl mb-4">👓</div>
                        <div className="text-white font-mono text-sm">
                          <span className="text-green-400">●</span> Real-time Vision Processing
                        </div>
                        <div className="mt-2 text-gray-400 text-xs font-mono">
                          FPS: 25+ | Objects: Tracking | Voice: Active
                        </div>
                      </div>
                    </div>
                    {/* Scanning animation */}
                    <div className="absolute inset-0 overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-b from-brand/20 to-transparent animate-scan"></div>
                    </div>
                    {/* Detection boxes animation */}
                    <div className="absolute top-4 left-4 w-16 h-12 border-2 border-green-400 rounded animate-pulse"></div>
                    <div className="absolute bottom-8 right-8 w-20 h-16 border-2 border-blue-400 rounded animate-pulse" style={{animationDelay: '0.5s'}}></div>
                    <div className="absolute top-1/2 left-1/3 w-24 h-32 border-2 border-purple-400 rounded animate-pulse" style={{animationDelay: '1s'}}></div>
                  </div>
                  <div className="mt-4 flex justify-between text-xs text-gray-400 font-mono">
                    <span>🎯 YOLO Detection</span>
                    <span>🧠 Scene Analysis</span>
                    <span>🔊 TTS Ready</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* Stats Section */}
        <section className="mb-24">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-xl p-6 text-center shadow-lg border border-gray-200 dark:border-gray-700"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="text-3xl font-bold text-brand mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Features Section */}
        <section className="mb-24">
          <div className="text-center mb-16">
            <motion.h2 
              className="text-3xl font-bold mb-4 text-gray-800 dark:text-white"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              Core Features
            </motion.h2>
            <motion.p 
              className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              viewport={{ once: true }}
            >
              A comprehensive suite of AI-powered features designed for real-world accessibility
            </motion.p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="group p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200 dark:border-gray-700 hover:border-brand/50 transition-all"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <div className="text-3xl mb-4 transition-transform group-hover:scale-110 text-brand">
                  {typeof feature.icon === 'string' ? feature.icon : feature.icon}
                </div>
                <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-white">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Architecture Section */}
        <section className="mb-24">
          <div className="text-center mb-16">
            <motion.h2 
              className="text-3xl font-bold mb-4 text-gray-800 dark:text-white"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              System Architecture
            </motion.h2>
            <motion.p 
              className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              viewport={{ once: true }}
            >
              Modular, production-grade codebase designed for real-time performance
            </motion.p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            {architectureModules.map((module, index) => (
              <motion.div
                key={index}
                className="flex items-start gap-4 p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-xl border border-gray-200 dark:border-gray-700"
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="flex-shrink-0 w-12 h-12 bg-brand/10 dark:bg-brand/20 rounded-lg flex items-center justify-center">
                  <span className="text-brand font-mono text-xs">{module.lines}</span>
                </div>
                <div>
                  <h4 className="font-mono text-sm font-bold text-gray-800 dark:text-white">{module.name}</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{module.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Tech Stack */}
        <section className="mb-24">
          <div className="text-center mb-16">
            <motion.h2 
              className="text-3xl font-bold mb-4 text-gray-800 dark:text-white"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              Technology Stack
            </motion.h2>
            <motion.p 
              className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              viewport={{ once: true }}
            >
              Cutting-edge AI and computer vision technologies
            </motion.p>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4">
            {techStack.map((tech, index) => (
              <motion.div
                key={index}
                className={`px-5 py-3 rounded-full ${tech.bg} text-white font-medium shadow-md`}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05 }}
              >
                {tech.name}
              </motion.div>
            ))}
          </div>
          
          <motion.div 
            className="mt-16 bg-gradient-to-r from-brand/10 to-accent/10 dark:from-brand/20 dark:to-accent/20 rounded-2xl p-8 border border-indigo-100 dark:border-gray-700"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">Technical Challenges</h3>
                <ul className="space-y-3 text-gray-700 dark:text-gray-300">
                  <li className="flex items-start gap-3">
                    <div className="bg-yellow-100 dark:bg-yellow-900/30 p-1 rounded-full text-yellow-500 dark:text-yellow-400 mt-1">•</div>
                    <div>Achieving 25+ FPS while running multiple AI models simultaneously</div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="bg-yellow-100 dark:bg-yellow-900/30 p-1 rounded-full text-yellow-500 dark:text-yellow-400 mt-1">•</div>
                    <div>Eliminating detection flickering with temporal smoothing and Kalman filtering</div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="bg-yellow-100 dark:bg-yellow-900/30 p-1 rounded-full text-yellow-500 dark:text-yellow-400 mt-1">•</div>
                    <div>Resolving MediaPipe and face-recognition dependencies on macOS ARM</div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="bg-yellow-100 dark:bg-yellow-900/30 p-1 rounded-full text-yellow-500 dark:text-yellow-400 mt-1">•</div>
                    <div>Balancing safety alerts without overwhelming the user (spam prevention)</div>
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">Solutions Implemented</h3>
                <ul className="space-y-3 text-gray-700 dark:text-gray-300">
                  <li className="flex items-start gap-3">
                    <div className="bg-green-100 dark:bg-green-900/30 p-1 rounded-full text-green-500 dark:text-green-400 mt-1">✓</div>
                    <div>Frame skipping, GPU acceleration, and half-precision inference</div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="bg-green-100 dark:bg-green-900/30 p-1 rounded-full text-green-500 dark:text-green-400 mt-1">✓</div>
                    <div>Triple-buffered temporal voting and hysteresis-based state transitions</div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="bg-green-100 dark:bg-green-900/30 p-1 rounded-full text-green-500 dark:text-green-400 mt-1">✓</div>
                    <div>Custom build scripts and fallback implementations for cross-platform support</div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="bg-green-100 dark:bg-green-900/30 p-1 rounded-full text-green-500 dark:text-green-400 mt-1">✓</div>
                    <div>Smart cooldowns, severity escalation, and reading-mode muting</div>
                  </li>
                </ul>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Key Highlights */}
        <section className="mb-24">
          <motion.div 
            className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-3xl p-8 md:p-12 text-white"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold mb-8 text-center">Key Highlights</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-brand/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-brand">🎯</span>
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Human-Centered Design</h4>
                    <p className="text-gray-400 text-sm">Every feature designed with visually impaired users in mind - TTS optimization, voice-friendly responses, and non-intrusive alerts</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-brand/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-brand">⚡</span>
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Real-Time Performance</h4>
                    <p className="text-gray-400 text-sm">Optimized for 25+ FPS with multiple AI models running concurrently through smart frame skipping and GPU acceleration</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-brand/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-brand">🔧</span>
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Highly Configurable</h4>
                    <p className="text-gray-400 text-sm">100+ configuration options via environment variables for fine-tuning detection thresholds, cooldowns, and behavior</p>
                  </div>
                </div>
              </div>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-brand/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-brand">🧪</span>
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Production-Grade Code</h4>
                    <p className="text-gray-400 text-sm">Comprehensive error handling, telemetry logging, and modular architecture ready for deployment</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-brand/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-brand">🔄</span>
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Multi-Modal AI</h4>
                    <p className="text-gray-400 text-sm">Seamless integration of vision, language, and speech AI models for comprehensive environmental understanding</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-brand/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-brand">♿</span>
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Accessibility First</h4>
                    <p className="text-gray-400 text-sm">Built from the ground up for accessibility with wheelchair navigation support, sign language interpretation, and safety alerts</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Call to Action */}
        <motion.div 
          className="text-center py-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">Explore the Code</h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 mb-8 max-w-2xl mx-auto">
            This capstone project represents months of development, research, and iteration. 
            Explore the full implementation on GitHub.
          </p>
          <a
            href="https://github.com/mohalsheikh/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gray-800 dark:bg-gray-700 text-white hover:bg-gray-700 dark:hover:bg-gray-600 transition-colors text-lg font-medium"
          >
            <FiGithub />
            View Source Code on GitHub
          </a>
        </motion.div>
      </div>

      {/* Custom animation styles */}
      <style>{`
        @keyframes scan {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }
        .animate-scan {
          animation: scan 2s linear infinite;
        }
      `}</style>
    </div>
  );
}